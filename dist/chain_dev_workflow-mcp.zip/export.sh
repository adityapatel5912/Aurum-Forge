#!/usr/bin/env bash
echo "Hot-loading chain_dev_workflow..."
python3 server.py
