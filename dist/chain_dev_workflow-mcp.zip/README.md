# chain_dev_workflow — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Continuous delivery co-pilot: monitors open GitHub PRs, analyzes code diffs on disk, posts reviewer alerts to engineering Slack, and auto-generates release changelogs in Notion. Rewrites 4 hours of engineering lead labor.

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
