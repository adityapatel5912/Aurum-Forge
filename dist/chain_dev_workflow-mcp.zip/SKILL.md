---
name: chain_dev_workflow
description: Continuous delivery co-pilot: monitors open GitHub PRs, analyzes code diffs on disk, posts reviewer alerts to engineerin
version: 1.0.0
mcp_server: chain_dev_workflow
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Cursor
  - Antigravity
  - Codex
  - Z Code
---

# Universal Skill: Continuous delivery co-pilot: monitors open GitHub PRs, analyzes code diffs on disk, posts reviewer alerts to engineering Slack, and auto-generates release changelogs in Notion. Rewrites 4 hours of engineering lead labor.

## 1. Overview & Golden Badge
- **MCP Server Name**: `chain_dev_workflow`
- **Server Path**: `mcp/chain_dev_workflow/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Continuous delivery co-pilot: monitors open GitHub PRs, analyzes code diffs on disk, posts reviewer alerts to engineering Slack, and auto-generates release changelogs in Notion. Rewrites 4 hours of engineering lead labor.

## 2. FastMCP Tool Manifest
- `github_watch_prs` [AURUM GOLD]: Fetches newly submitted PRs and checks status
- `filesystem_scan_diffs` [AURUM GOLD]: Validates local patch safety and AST correctness
- `slack_notify_dev_channel` [AURUM GOLD]: Posts pull request approval status to Slack
- `notion_update_changelog` [AURUM GOLD]: Compiles release notes and commits to Notion
- `run_dev_workflow_chain` [AURUM GOLD]: Executes full Dev Lead Chain pipeline end-to-end

## 3. Levelled Workflow DAG
```json
{
  "T1_github_prs": {
    "tool": "github_watch_prs",
    "source": "GitHub MCP",
    "category": "trigger",
    "color": "#3B82F6",
    "deps": [],
    "params": {
      "repo": "org/core-engine",
      "state": "open"
    }
  },
  "T2_fs_diffs": {
    "tool": "filesystem_scan_diffs",
    "source": "Filesystem MCP",
    "category": "process",
    "color": "#10B981",
    "deps": [
      "T1_github_prs"
    ],
    "params": {
      "verify_ast": true,
      "check_breakages": true
    }
  },
  "T3_slack_devs": {
    "tool": "slack_notify_dev_channel",
    "source": "Slack MCP",
    "category": "output",
    "color": "#8B5CF6",
    "deps": [
      "T2_fs_diffs"
    ],
    "params": {
      "channel": "#eng-release",
      "text": "PR Verified: All tests passing"
    }
  },
  "T4_notion_changelog": {
    "tool": "notion_update_changelog",
    "source": "Notion MCP",
    "category": "output",
    "color": "#C6A96B",
    "gold_pulse": true,
    "deps": [
      "T3_slack_devs"
    ],
    "params": {
      "title": "Release v2.4.0 Changelog",
      "database_id": "auto"
    }
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Continuous delivery co-pilot: monitors open GitHub PRs, analyzes code diffs on disk, posts reviewer alerts to engineering Slack, and auto-generates release changelogs in Notion. Rewrites 4 hours of engineering lead labor."** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `chain_dev_workflow` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Cursor**: Add to `.cursor/mcp.json` in workspace or `~/.cursor/mcp.json`
- **Antigravity**: Add `chain_dev_workflow` to `~/.gemini/antigravity/mcp_config.json` or `~/.antigravity/mcp.json`
- **Codex**: Run `codex mcp add chain_dev_workflow -- python "mcp/chain_dev_workflow/server.py"` or add to `~/.codex/config.json`
- **Z Code**: Add `chain_dev_workflow` to `settings.json` under `context_servers` or `~/.zcode/mcp.json`
