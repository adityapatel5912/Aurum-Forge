#!/usr/bin/env bash
echo "Hot-loading youtube_mcp..."
python3 server.py
