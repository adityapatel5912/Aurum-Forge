# youtube_mcp — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Build YouTube MCP that gets transcript and summaries with 3 tools youtube_get_transcript youtube_summarize youtube_search

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
