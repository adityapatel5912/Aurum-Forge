---
name: youtube_mcp
description: Build YouTube MCP that gets transcript and summaries with 3 tools youtube_get_transcript youtube_summarize youtube_searc
version: 1.0.0
mcp_server: youtube_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build YouTube MCP that gets transcript and summaries with 3 tools youtube_get_transcript youtube_summarize youtube_search

## 1. Overview & Golden Badge
- **MCP Server Name**: `youtube_mcp`
- **Server Path**: `mcp/youtube_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build YouTube MCP that gets transcript and summaries with 3 tools youtube_get_transcript youtube_summarize youtube_search

## 2. FastMCP Tool Manifest
- `youtube_get_transcript` [FORGED]: Extract 3200+ char transcript with timestamps
- `youtube_summarize` [FORGED]: Summarize transcript into key takeaways
- `youtube_search` [FORGED]: Search YouTube videos and titles

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "youtube_get_transcript",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "youtube_summarize",
    "source": "Intent Router",
    "parallel": true
  },
  "t3": {
    "tool": "youtube_search",
    "source": "Intent Router",
    "parallel": true
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build YouTube MCP that gets transcript and summaries with 3 tools youtube_get_transcript youtube_summarize youtube_search"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `youtube_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `youtube_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `youtube_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add youtube_mcp -- python "mcp/youtube_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
