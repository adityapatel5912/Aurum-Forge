# chain_research — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Autonomous end-to-end repository deep-dive: clones & inspects GitHub repo, crawls linked docs, generates comprehensive Notion technical dossier, and dispatches executive email briefing. Rewrites 4 hours of researcher labor.

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
