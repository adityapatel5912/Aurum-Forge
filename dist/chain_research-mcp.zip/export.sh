#!/usr/bin/env bash
echo "Hot-loading chain_research..."
python3 server.py
