---
name: browser_mcp
description: Build Browser MCP that fetches and enriches web pages with 2 tools browser_fetch browser_enrich
version: 1.0.0
mcp_server: browser_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build Browser MCP that fetches and enriches web pages with 2 tools browser_fetch browser_enrich

## 1. Overview & Golden Badge
- **MCP Server Name**: `browser_mcp`
- **Server Path**: `mcp/browser_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build Browser MCP that fetches and enriches web pages with 2 tools browser_fetch browser_enrich

## 2. FastMCP Tool Manifest
- `browser_fetch` [FORGED]: Fetch web page markdown and headings
- `browser_enrich` [FORGED]: Enrich page with citations and fact checks

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "browser_fetch",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "browser_enrich",
    "source": "Intent Router",
    "parallel": true
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build Browser MCP that fetches and enriches web pages with 2 tools browser_fetch browser_enrich"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `browser_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `browser_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `browser_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add browser_mcp -- python "mcp/browser_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
