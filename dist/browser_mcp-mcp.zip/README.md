# browser_mcp — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Build Browser MCP that fetches and enriches web pages with 2 tools browser_fetch browser_enrich

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
