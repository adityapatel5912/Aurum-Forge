#!/usr/bin/env bash
echo "Hot-loading browser_mcp..."
python3 server.py
