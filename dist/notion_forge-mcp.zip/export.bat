@echo off
REM FORGE 1-Click Multi-Agent MCP Exporter (Windows)
echo ========================================================
echo Exporting MCP Server 'notion_forge' to AI Agents...
echo Server Path: D:/Aditya/Forge/mcp/notion_forge/server.py
echo ========================================================

echo [1/3] Adding to Claude Code...
where claude >nul 2>nul
if %errorlevel%==0 (
    claude mcp add notion_forge -- python "D:/Aditya/Forge/mcp/notion_forge/server.py"
    echo [OK] Claude Code configured.
) else (
    echo [SKIP] Claude Code CLI not installed.
)

echo [2/3] Adding to Codex...
where codex >nul 2>nul
if %errorlevel%==0 (
    codex mcp add notion_forge -- python "D:/Aditya/Forge/mcp/notion_forge/server.py"
    echo [OK] Codex configured.
) else (
    echo [SKIP] Codex CLI not installed.
)

echo [3/3] Adding to OpenCode...
where opencode >nul 2>nul
if %errorlevel%==0 (
    opencode mcp add notion_forge -- python "D:/Aditya/Forge/mcp/notion_forge/server.py"
    echo [OK] OpenCode configured.
) else (
    echo [SKIP] OpenCode CLI not installed.
)

echo.
echo For Cursor, Zed, and Antigravity, see export_configs.json for copy-paste configuration.
echo Done!
