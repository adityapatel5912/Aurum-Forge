# FORGE UNIFIED MCP — CONFIG ONCE

One server (monitor_github_issues_and_send_v2) operates 3 custom site(s) + 3 official MCP(s).
0 core + 15 forged + 9 official = 24 tools total.

## Setup — one time only

1. Unzip this archive anywhere you like.
2. Install dependencies:
   ```
   pip install -r requirements.txt && playwright install chromium
   ```
3. Export to your AI Agent:
   - Run `export.bat` (Windows) or `bash export.sh` (macOS / Linux) to configure Claude Code, Codex, and OpenCode automatically.
   - For Cursor, Zed, and Antigravity: consult `export_configs.json` for ready-to-use JSON blocks.
4. Workflow Skill:
   `SKILL.md` is provided at the root as the single source of truth for your agent.

## Official MCP tokens

- `NOTION_TOKEN` / `NOTION_DATABASE_ID` — Notion core (log_price, create entry)
- `GMAIL_USER` / `GMAIL_APP_PASSWORD` / `GMAIL_TO` — Gmail core (SMTP app password)
- `TELEGRAM_BOT_TOKEN` — for the Telegram wrapper you selected
- `TELEGRAM_BOT_TOKEN` — for the Telegram wrapper you selected
- `TELEGRAM_BOT_TOKEN` — for the Telegram wrapper you selected
- `TELEGRAM_BOT_TOKEN` — for the Telegram wrapper you selected
- `SLACK_BOT_TOKEN` — for the Slack wrapper you selected
- `SLACK_BOT_TOKEN` — for the Slack wrapper you selected
- `GITHUB_TOKEN` — for the GitHub wrapper you selected
- `GITHUB_TOKEN` — for the GitHub wrapper you selected
- `GITHUB_TOKEN` — for the GitHub wrapper you selected

## Test without any client

```
npx @modelcontextprotocol/inspector python server.py
```
or simply:
```
python server.py --list-tools
```

## Hardcoded core tools (always included, no LLM was used)

- none

## Forged tools (browser automation, two-locator self-healing)

- `search_news_ycombinator` — Custom news.ycombinator.com Forged
- `read_page_news_ycombinator` — Custom news.ycombinator.com Forged
- `click_element_news_ycombinator` — Custom news.ycombinator.com Forged
- `fill_field_news_ycombinator` — Custom news.ycombinator.com Forged
- `extract_links_news_ycombinator` — Custom news.ycombinator.com Forged
- `search_arxiv` — Custom arxiv.org Forged
- `read_page_arxiv` — Custom arxiv.org Forged
- `click_element_arxiv` — Custom arxiv.org Forged
- `fill_field_arxiv` — Custom arxiv.org Forged
- `extract_links_arxiv` — Custom arxiv.org Forged
- `search_spaceflightnow` — Custom spaceflightnow.com Forged
- `read_page_spaceflightnow` — Custom spaceflightnow.com Forged
- `click_element_spaceflightnow` — Custom spaceflightnow.com Forged
- `fill_field_spaceflightnow` — Custom spaceflightnow.com Forged
- `extract_links_spaceflightnow` — Custom spaceflightnow.com Forged

## Official wrappers

- `telegram_send_message` — Official Telegram
- `telegram_get_updates` — Official Telegram
- `telegram_send_photo` — Official Telegram
- `telegram_get_chat` — Official Telegram
- `slack_post_message` — Official Slack
- `slack_list_channels` — Official Slack
- `github_create_issue` — Official GitHub
- `github_list_prs` — Official GitHub
- `github_get_file_contents` — Official GitHub

---
Forged by FORGE v2.0.0 — Turn Any Website Into A Reusable MCP Server.
