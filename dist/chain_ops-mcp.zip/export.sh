#!/usr/bin/env bash
echo "Hot-loading chain_ops..."
python3 server.py
