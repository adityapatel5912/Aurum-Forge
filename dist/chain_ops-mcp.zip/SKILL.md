---
name: chain_ops
description: Autonomous business operations hub: monitors local filesystem drop directory, parses CSV/JSON telemetry, appends structu
version: 1.0.0
mcp_server: chain_ops
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Cursor
  - Antigravity
  - Codex
  - Z Code
---

# Universal Skill: Autonomous business operations hub: monitors local filesystem drop directory, parses CSV/JSON telemetry, appends structured rows to Google Sheets, syncs Notion KPI dashboard, and fires email report. Rewrites 4 hours of ops analyst labor.

## 1. Overview & Golden Badge
- **MCP Server Name**: `chain_ops`
- **Server Path**: `mcp/chain_ops/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Autonomous business operations hub: monitors local filesystem drop directory, parses CSV/JSON telemetry, appends structured rows to Google Sheets, syncs Notion KPI dashboard, and fires email report. Rewrites 4 hours of ops analyst labor.

## 2. FastMCP Tool Manifest
- `filesystem_watch_folder` [AURUM GOLD]: Scans local incoming folder for new telemetry logs
- `sheets_append_metrics` [AURUM GOLD]: Appends parsed numerical rows to Google Sheets table
- `notion_sync_ops_dashboard` [AURUM GOLD]: Updates operations dashboard block in Notion
- `gmail_send_ops_report` [AURUM GOLD]: Sends HTML daily operations digest
- `run_ops_chain` [AURUM GOLD]: Executes full Ops Chain pipeline end-to-end

## 3. Levelled Workflow DAG
```json
{
  "T1_fs_watch": {
    "tool": "filesystem_watch_folder",
    "source": "Filesystem MCP",
    "category": "trigger",
    "color": "#3B82F6",
    "deps": [],
    "params": {
      "folder": "data/incoming_reports",
      "pattern": "*.json"
    }
  },
  "T2_sheets_append": {
    "tool": "sheets_append_metrics",
    "source": "Sheets MCP",
    "category": "process",
    "color": "#10B981",
    "deps": [
      "T1_fs_watch"
    ],
    "params": {
      "spreadsheet_id": "auto",
      "range": "Q3_Ops!A1"
    }
  },
  "T3_notion_sync": {
    "tool": "notion_sync_ops_dashboard",
    "source": "Notion MCP",
    "category": "output",
    "color": "#8B5CF6",
    "deps": [
      "T2_sheets_append"
    ],
    "params": {
      "title": "Daily Operations Status",
      "status": "Green"
    }
  },
  "T4_gmail_report": {
    "tool": "gmail_send_ops_report",
    "source": "Gmail MCP",
    "category": "output",
    "color": "#C6A96B",
    "gold_pulse": true,
    "deps": [
      "T3_notion_sync"
    ],
    "params": {
      "to": "ops-team@company.com",
      "subject": "Daily KPI & Ops Report"
    }
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Autonomous business operations hub: monitors local filesystem drop directory, parses CSV/JSON telemetry, appends structured rows to Google Sheets, syncs Notion KPI dashboard, and fires email report. Rewrites 4 hours of ops analyst labor."** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `chain_ops` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Cursor**: Add to `.cursor/mcp.json` in workspace or `~/.cursor/mcp.json`
- **Antigravity**: Add `chain_ops` to `~/.gemini/antigravity/mcp_config.json` or `~/.antigravity/mcp.json`
- **Codex**: Run `codex mcp add chain_ops -- python "mcp/chain_ops/server.py"` or add to `~/.codex/config.json`
- **Z Code**: Add `chain_ops` to `settings.json` under `context_servers` or `~/.zcode/mcp.json`
