# chain_ops — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Autonomous business operations hub: monitors local filesystem drop directory, parses CSV/JSON telemetry, appends structured rows to Google Sheets, syncs Notion KPI dashboard, and fires email report. Rewrites 4 hours of ops analyst labor.

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
