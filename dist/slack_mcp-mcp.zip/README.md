# slack_mcp — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Build Slack MCP that posts messages and reads channels with 2 tools slack_post_message slack_read_channel

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
