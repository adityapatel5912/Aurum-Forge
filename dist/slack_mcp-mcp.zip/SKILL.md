---
name: slack_mcp
description: Build Slack MCP that posts messages and reads channels with 2 tools slack_post_message slack_read_channel
version: 1.0.0
mcp_server: slack_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build Slack MCP that posts messages and reads channels with 2 tools slack_post_message slack_read_channel

## 1. Overview & Golden Badge
- **MCP Server Name**: `slack_mcp`
- **Server Path**: `mcp/slack_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build Slack MCP that posts messages and reads channels with 2 tools slack_post_message slack_read_channel

## 2. FastMCP Tool Manifest
- `slack_post_message` [FORGED]: Post messages to Slack channel
- `slack_read_channel` [FORGED]: Read messages from Slack channel

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "slack_post_message",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "slack_read_channel",
    "source": "Intent Router",
    "parallel": true
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build Slack MCP that posts messages and reads channels with 2 tools slack_post_message slack_read_channel"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `slack_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `slack_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `slack_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add slack_mcp -- python "mcp/slack_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
