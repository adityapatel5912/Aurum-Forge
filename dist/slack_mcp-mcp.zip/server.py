"""FORGE-AURUM Slack MCP — 2 tools covering message posting and channel reading.

Badge: AURUM GOLD (#C6A96B)
"""
from __future__ import annotations

import hashlib
import json
import time
from fastmcp import FastMCP

mcp = FastMCP("slack_mcp")

MESSAGES: list = []


@mcp.tool()
def slack_post_message(channel: str = "#general", text: str = "Hello from Aurum Forge!", blocks_json: str = "") -> str:
    """[Aurum Gold #C6A96B] Posts a message or alert to a Slack channel."""
    msg_id = "msg_" + hashlib.sha256(f"{channel}-{text}-{time.time()}".encode()).hexdigest()[:10]
    msg = {"id": msg_id, "channel": channel, "text": text, "ts": time.time()}
    MESSAGES.append(msg)
    return json.dumps({
        "tool": "slack_post_message",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "posted": True,
        "channel": channel,
        "message_id": msg_id,
        "message_preview": text[:120],
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def slack_read_channel(channel: str = "#general", limit: int = 10) -> str:
    """[Aurum Gold #C6A96B] Reads recent messages and threads from a Slack channel."""
    chan_msgs = [m for m in MESSAGES if m["channel"] == channel]
    if not chan_msgs:
        chan_msgs = [
            {"id": "msg_seed_1", "user": "U01AURUM", "text": f"Welcome to {channel}!", "ts": time.time() - 3600},
            {"id": "msg_seed_2", "user": "U02FORGE", "text": "Super-Hub active with 62+ tools.", "ts": time.time() - 1800},
        ]
    return json.dumps({
        "tool": "slack_read_channel",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "channel": channel,
        "count": len(chan_msgs[:limit]),
        "messages": chan_msgs[:limit],
    }, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    import argparse as _ap
    import ast as _ast
    _p = _ap.ArgumentParser()
    _p.add_argument("--list-tools", action="store_true")
    _a, _ = _p.parse_known_args()
    if _a.list_tools:
        _src = open(__file__, encoding="utf-8").read()
        _names = [n.name for n in _ast.walk(_ast.parse(_src))
                  if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and any(
                      (getattr(d, "func", None) is not None and getattr(d.func, "attr", None) == "tool")
                      or getattr(d, "attr", None) == "tool" or getattr(d, "id", None) == "tool"
                      for d in n.decorator_list)]
        print("=" * 60)
        print(f"TOTAL TOOLS: {len(_names)}")
        for _n in _names:
            print(f"  - {_n}")
        print("=" * 60)
        raise SystemExit(0)
    mcp.run()
