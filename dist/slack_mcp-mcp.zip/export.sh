#!/usr/bin/env bash
echo "Hot-loading slack_mcp..."
python3 server.py
