# FORGE UNIFIED MCP — CONFIG ONCE

One server (stress_3) operates 1 custom site(s) + 1 official MCP(s).
7 core + 5 forged + 1 official = 13 tools total.

## Setup — one time only

1. Unzip this archive anywhere you like.
2. Install dependencies:
   ```
   pip install -r requirements.txt && playwright install chromium
   ```
3. Export to your AI Agent:
   - Run `export.bat` (Windows) or `bash export.sh` (macOS / Linux) to configure Claude Code, Codex, and OpenCode automatically.
   - For Cursor, Zed, and Antigravity: consult `export_configs.json` for ready-to-use JSON blocks.
4. Workflow Skill:
   `SKILL.md` is provided at the root as the single source of truth for your agent.

## Official MCP tokens

- `NOTION_TOKEN` / `NOTION_DATABASE_ID` — Notion core (log_price, create entry)
- `GMAIL_USER` / `GMAIL_APP_PASSWORD` / `GMAIL_TO` — Gmail core (SMTP app password)
- `NOTION_TOKEN` — for the Notion wrapper you selected

## Test without any client

```
npx @modelcontextprotocol/inspector python server.py
```
or simply:
```
python server.py --list-tools
```

## Hardcoded core tools (always included, no LLM was used)

- `amazon_search_ram` — Core Amazon (hardcoded, always available)
- `amazon_check_discount` — Core Amazon (hardcoded, always available)
- `amazon_monitor_ram_discount` — Core Amazon (hardcoded, always available)
- `gmail_send_email` — Core Gmail (hardcoded, always available)
- `gmail_notify_and_log` — Core Gmail (hardcoded, always available)
- `notion_create_database_entry` — Core Notion (hardcoded, always available)
- `notion_log_price` — Core Notion (hardcoded, always available)

## Forged tools (browser automation, two-locator self-healing)

- `search_example` — Custom example.com Forged
- `read_page_example` — Custom example.com Forged
- `click_element_example` — Custom example.com Forged
- `fill_field_example` — Custom example.com Forged
- `extract_links_example` — Custom example.com Forged

## Official wrappers

- `notion_create_entry` — Official Notion

---
Forged by FORGE v2.0.0 — Turn Any Website Into A Reusable MCP Server.
