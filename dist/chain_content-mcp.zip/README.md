# chain_content — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Video-to-social pipeline: extracts YouTube timestamps and transcripts, verifies web references, creates structured Notion blog/briefing, and broadcasts instant launch alert to Slack channel. Rewrites 4 hours of content creator labor.

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
