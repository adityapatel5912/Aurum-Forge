#!/usr/bin/env bash
echo "Hot-loading chain_content..."
python3 server.py
