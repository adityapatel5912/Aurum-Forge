---
name: chain_content
description: Video-to-social pipeline: extracts YouTube timestamps and transcripts, verifies web references, creates structured Notio
version: 1.0.0
mcp_server: chain_content
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Cursor
  - Antigravity
  - Codex
  - Z Code
---

# Universal Skill: Video-to-social pipeline: extracts YouTube timestamps and transcripts, verifies web references, creates structured Notion blog/briefing, and broadcasts instant launch alert to Slack channel. Rewrites 4 hours of content creator labor.

## 1. Overview & Golden Badge
- **MCP Server Name**: `chain_content`
- **Server Path**: `mcp/chain_content/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Video-to-social pipeline: extracts YouTube timestamps and transcripts, verifies web references, creates structured Notion blog/briefing, and broadcasts instant launch alert to Slack channel. Rewrites 4 hours of content creator labor.

## 2. FastMCP Tool Manifest
- `youtube_get_transcript` [AURUM GOLD]: Extracts full timestamps & text transcript from video
- `browser_fetch_enrich` [AURUM GOLD]: Fetches background articles & citation links
- `chain_content_summarize` [AURUM GOLD]: Summarizes transcript into structured bullets
- `notion_create_page` [AURUM GOLD]: Creates formatted article draft in Notion CMS
- `slack_post_message` [AURUM GOLD]: Sends broadcast notification to Slack channel
- `chain_content_full_workflow` [AURUM GOLD]: Executes full Content Creator Chain pipeline end-to-end with Proof Ledger

## 3. Levelled Workflow DAG
```json
{
  "T1_youtube_transcript": {
    "tool": "youtube_get_transcript",
    "source": "YouTube MCP",
    "category": "trigger",
    "color": "#3B82F6",
    "deps": [],
    "params": {
      "url": "https://www.youtube.com/watch?v=0ASanC5Iv-k"
    }
  },
  "T2_browser_factcheck": {
    "tool": "browser_fetch_enrich",
    "source": "Browser MCP",
    "category": "process",
    "color": "#10B981",
    "deps": [
      "T1_youtube_transcript"
    ],
    "params": {
      "keywords": "AI Agent architectures 2026"
    }
  },
  "T3_summarize": {
    "tool": "chain_content_summarize",
    "source": "Chain Core",
    "category": "process",
    "color": "#10B981",
    "deps": [
      "T2_browser_factcheck"
    ],
    "params": {
      "style": "bullets"
    }
  },
  "T4_notion_content": {
    "tool": "notion_create_page",
    "source": "Notion MCP",
    "category": "output",
    "color": "#8B5CF6",
    "deps": [
      "T3_summarize"
    ],
    "params": {
      "title": "Key Takeaways & Video Summary",
      "database_id": "auto"
    }
  },
  "T5_slack_broadcast": {
    "tool": "slack_post_message",
    "source": "Slack MCP",
    "category": "output",
    "color": "#C6A96B",
    "gold_pulse": true,
    "deps": [
      "T4_notion_content"
    ],
    "params": {
      "channel": "#content",
      "text": "New Video Summary Published to Notion"
    }
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Video-to-social pipeline: extracts YouTube timestamps and transcripts, verifies web references, creates structured Notion blog/briefing, and broadcasts instant launch alert to Slack channel. Rewrites 4 hours of content creator labor."** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `chain_content` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Cursor**: Add to `.cursor/mcp.json` in workspace or `~/.cursor/mcp.json`
- **Antigravity**: Add `chain_content` to `~/.gemini/antigravity/mcp_config.json` or `~/.antigravity/mcp.json`
- **Codex**: Run `codex mcp add chain_content -- python "mcp/chain_content/server.py"` or add to `~/.codex/config.json`
- **Z Code**: Add `chain_content` to `settings.json` under `context_servers` or `~/.zcode/mcp.json`
