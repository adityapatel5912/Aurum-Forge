#!/usr/bin/env bash
echo "Hot-loading hello_mcp..."
python3 server.py
