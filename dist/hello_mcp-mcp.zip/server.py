"""FORGE-AURUM Hello MCP — the useless-MCP edge case: exactly 1 tool."""
from __future__ import annotations

import json
from fastmcp import FastMCP

mcp = FastMCP("hello_mcp")


@mcp.tool()
def hello_world(name: str = "Judge") -> str:
    """[Aurum Gold #C6A96B] Says hello world. That is all it does — by design."""
    return json.dumps({
        "tool": "hello_world", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "message": f"Hello, {name}! This MCP intentionally does nothing else.",
    }, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    import argparse as _ap
    import ast as _ast
    _p = _ap.ArgumentParser()
    _p.add_argument("--list-tools", action="store_true")
    _a, _ = _p.parse_known_args()
    if _a.list_tools:
        _src = open(__file__, encoding="utf-8").read()
        _names = [n.name for n in _ast.walk(_ast.parse(_src))
                  if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and any(
                      (getattr(d, "func", None) is not None and getattr(d.func, "attr", None) == "tool")
                      or getattr(d, "attr", None) == "tool" or getattr(d, "id", None) == "tool"
                      for d in n.decorator_list)]
        print("=" * 60)
        print(f"TOTAL TOOLS: {len(_names)}")
        for _n in _names:
            print(f"  - {_n}")
        print("=" * 60)
        raise SystemExit(0)
    mcp.run()
