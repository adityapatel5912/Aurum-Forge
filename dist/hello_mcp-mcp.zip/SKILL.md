---
name: hello_mcp
description: Make a useless MCP that does nothing but says hello world
version: 1.0.0
mcp_server: hello_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Make a useless MCP that does nothing but says hello world

## 1. Overview & Golden Badge
- **MCP Server Name**: `hello_mcp`
- **Server Path**: `mcp/hello_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Make a useless MCP that does nothing but says hello world

## 2. FastMCP Tool Manifest
- `hello_world` [FORGED]: Says hello world — the useless-MCP edge case

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "hello_world",
    "source": "Intent Router",
    "parallel": true
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Make a useless MCP that does nothing but says hello world"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `hello_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `hello_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `hello_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add hello_mcp -- python "mcp/hello_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
