---
name: notion_workspace
description: Operate notion_workspace workflow
version: 1.0.0
mcp: notion_workspace
---

# Skill: Operate notion_workspace workflow

## Overview
This skill executes: Operate notion_workspace workflow
Uses MCP Server: notion_workspace with 2 tools

## MCP Tools (from server.py)
- search_site
- extract_data

## Workflow DAG
```json
{}
```

## Instructions for Agent (Performance Optimized)
You have MCP Server `notion_workspace` installed. Follow this exact sequence:

1. CALL mcp tool `search_site` or respective search tool from DAG T1
2. IF result meets threshold (discount >20%, prize>50000, price<2000):
   - CALL `gmail_send_email` (from notion_workspace) in parallel
   - CALL `notion_create_database_entry` (from notion_workspace) in parallel
3. Return summary

Do not re-discover tools — use notion_workspace tools directly. This SKILL.md is single source of truth for this workflow.

## When to Invoke
User says: "Operate notion_workspace workflow" or similar to RAM/hackathon/tee tracking

## Expected Output
- Email sent
- Notion logged
- Summary returned
