"""FORGE-AURUM Notion Workspace — 5 tools covering pages and databases.

Deterministic in-memory Notion-style store (zero external API, zero tokens).
Badge: AURUM GOLD (#C6A96B)
"""
from __future__ import annotations

import hashlib
import json
import time
from fastmcp import FastMCP

mcp = FastMCP("notion_workspace")

PAGES: dict = {}
DATABASES: dict = {}


def _hid(prefix: str, text: str) -> str:
    return f"{prefix}-" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


@mcp.tool()
def notion_create_page(title: str = "New Page", content: str = "", database_id: str = "auto") -> str:
    """[Aurum Gold #C6A96B] Create a Notion page and return its notion.so URL."""
    page_id = _hid("page", f"{title}-{time.time()}")
    url = f"https://notion.so/Aurum-Forge-{page_id.split('-', 1)[1]}"
    PAGES[page_id] = {"id": page_id, "title": title, "content": content,
                        "database_id": database_id, "url": url,
                        "created_at": time.time()}
    return json.dumps({
        "tool": "notion_create_page", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "page_id": page_id, "title": title, "notion_url": url,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def notion_search(query: str = "", limit: int = 10) -> str:
    """[Aurum Gold #C6A96B] Full-text search across created pages and databases."""
    q = (query or "").lower()
    hits = [p for p in PAGES.values() if q in p["title"].lower() or q in (p.get("content") or "").lower()]
    db_hits = [d for d in DATABASES.values() if q in d["name"].lower()]
    return json.dumps({
        "tool": "notion_search", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "pages_found": len(hits), "databases_found": len(db_hits),
        "pages": hits[:limit], "databases": db_hits[:limit],
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def notion_create_database(name: str = "New Database", schema_json: str = "") -> str:
    """[Aurum Gold #C6A96B] Create a Notion database with an optional column schema."""
    db_id = _hid("db", name)
    url = f"https://notion.so/Aurum-Forge-DB-{db_id.split('-', 1)[1]}"
    try:
        schema = json.loads(schema_json) if schema_json else {"Name": "title"}
    except Exception:
        schema = {"Name": "title"}
    DATABASES[db_id] = {"id": db_id, "name": name, "schema": schema, "url": url}
    return json.dumps({
        "tool": "notion_create_database", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "database_id": db_id, "name": name, "schema": schema, "notion_url": url,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def notion_update_page(page_id: str = "page-001", title: str = "", content: str = "") -> str:
    """[Aurum Gold #C6A96B] Update an existing page's title and/or content."""
    page = PAGES.get(page_id)
    if not page:
        return json.dumps({"tool": "notion_update_page", "status": "not_found", "page_id": page_id}, indent=2)
    if title:
        page["title"] = title
    if content:
        page["content"] = content
    page["updated_at"] = time.time()
    return json.dumps({
        "tool": "notion_update_page", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "page_id": page_id, "notion_url": page["url"],
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def notion_query_database(database_id: str = "db-001", filter_json: str = "") -> str:
    """[Aurum Gold #C6A96B] Query records and schema from a Notion database."""
    db = DATABASES.get(database_id, {"id": database_id, "name": "Main Registry", "schema": {"Name": "title"}})
    rows = [p for p in PAGES.values() if p.get("database_id") == database_id]
    return json.dumps({
        "tool": "notion_query_database", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "database_id": database_id, "database_name": db.get("name"), "rows_count": len(rows),
        "rows": rows,
    }, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    import argparse as _ap
    import ast as _ast
    _p = _ap.ArgumentParser()
    _p.add_argument("--list-tools", action="store_true")
    _a, _ = _p.parse_known_args()
    if _a.list_tools:
        _src = open(__file__, encoding="utf-8").read()
        _names = [n.name for n in _ast.walk(_ast.parse(_src))
                  if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and any(
                      (getattr(d, "func", None) is not None and getattr(d.func, "attr", None) == "tool")
                      or getattr(d, "attr", None) == "tool" or getattr(d, "id", None) == "tool"
                      for d in n.decorator_list)]
        print("=" * 60)
        print(f"TOTAL TOOLS: {len(_names)}")
        for _n in _names:
            print(f"  - {_n}")
        print("=" * 60)
        raise SystemExit(0)
    mcp.run()
