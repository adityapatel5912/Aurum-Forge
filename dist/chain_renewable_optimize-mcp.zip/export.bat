@echo off
REM FORGE 1-Click Multi-Agent MCP Exporter (Windows)
setlocal EnableDelayedExpansion
set "SCRIPT_DIR=%~dp0"
set "LOCAL_SERVER=%SCRIPT_DIR%server.py"
if exist "!LOCAL_SERVER!" (
    set "RUN_PATH=!LOCAL_SERVER:\=/!"
) else (
    set "RUN_PATH=D:/Aditya/Forge/forge/mcp/chain_renewable_optimize/server.py"
)

echo ========================================================
echo Exporting MCP Server 'chain_renewable_optimize' to AI Agents...
echo Server Path: !RUN_PATH!
echo ========================================================

echo [1/3] Adding to Claude Code...
where claude >nul 2>nul
if %errorlevel%==0 (
    claude mcp add chain_renewable_optimize -- python "!RUN_PATH!"
    echo [OK] Claude Code configured.
) else (
    echo [SKIP] Claude Code CLI not installed.
)

echo [2/3] Adding to Codex...
where codex >nul 2>nul
if %errorlevel%==0 (
    codex mcp add chain_renewable_optimize -- python "!RUN_PATH!"
    echo [OK] Codex configured.
) else (
    echo [SKIP] Codex CLI not installed.
)

echo [3/3] Adding to OpenCode...
where opencode >nul 2>nul
if %errorlevel%==0 (
    opencode mcp add chain_renewable_optimize -- python "!RUN_PATH!"
    echo [OK] OpenCode configured.
) else (
    echo [SKIP] OpenCode CLI not installed.
)

echo.
echo For Cursor, Zed, and Antigravity, see export_configs.json for copy-paste configuration.
echo Done!
