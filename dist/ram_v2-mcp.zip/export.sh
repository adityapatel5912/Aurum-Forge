#!/usr/bin/env bash
# FORGE 1-Click Multi-Agent MCP Exporter (Linux / macOS)
set -e
echo "========================================================"
echo "Exporting MCP Server 'ram_v2' to AI Agents..."
echo "Server Path: D:/Aditya/Forge/mcp/ram_v2/server.py"
echo "========================================================"

if command -v claude &> /dev/null; then
    echo "[1/3] Adding to Claude Code..."
    claude mcp add ram_v2 -- python "D:/Aditya/Forge/mcp/ram_v2/server.py" || true
else
    echo "[SKIP] Claude Code CLI not found."
fi

if command -v codex &> /dev/null; then
    echo "[2/3] Adding to Codex..."
    codex mcp add ram_v2 -- python "D:/Aditya/Forge/mcp/ram_v2/server.py" || true
else
    echo "[SKIP] Codex CLI not found."
fi

if command -v opencode &> /dev/null; then
    echo "[3/3] Adding to OpenCode..."
    opencode mcp add ram_v2 -- python "D:/Aditya/Forge/mcp/ram_v2/server.py" || true
else
    echo "[SKIP] OpenCode CLI not found."
fi

echo ""
echo "For Cursor, Zed, and Antigravity, see export_configs.json for JSON configuration."
echo "Done!"
