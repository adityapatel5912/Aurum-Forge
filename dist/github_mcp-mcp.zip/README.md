# github_mcp — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Build GitHub MCP that searches repos and reads issues with 4 tools github_search_repos github_read_issue github_create_issue github_list_prs

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
