---
name: github_mcp
description: Build GitHub MCP that searches repos and reads issues with 4 tools github_search_repos github_read_issue github_create_i
version: 1.0.0
mcp_server: github_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build GitHub MCP that searches repos and reads issues with 4 tools github_search_repos github_read_issue github_create_issue github_list_prs

## 1. Overview & Golden Badge
- **MCP Server Name**: `github_mcp`
- **Server Path**: `mcp/github_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build GitHub MCP that searches repos and reads issues with 4 tools github_search_repos github_read_issue github_create_issue github_list_prs

## 2. FastMCP Tool Manifest
- `github_search_repos` [FORGED]: Search GitHub repositories
- `github_read_issue` [FORGED]: Read issue details and state
- `github_create_issue` [FORGED]: Create new issue in repo
- `github_list_prs` [FORGED]: List pull requests in repo

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "github_search_repos",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "github_read_issue",
    "source": "Intent Router",
    "parallel": true
  },
  "t3": {
    "tool": "github_create_issue",
    "source": "Intent Router",
    "parallel": true
  },
  "t4": {
    "tool": "github_list_prs",
    "source": "Intent Router",
    "deps": [
      "t1",
      "t2",
      "t3"
    ]
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build GitHub MCP that searches repos and reads issues with 4 tools github_search_repos github_read_issue github_create_issue github_list_prs"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `github_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `github_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `github_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add github_mcp -- python "mcp/github_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
