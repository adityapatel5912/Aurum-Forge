#!/usr/bin/env bash
echo "Hot-loading github_mcp..."
python3 server.py
