#!/usr/bin/env bash
echo "Hot-loading ram_tracker..."
python3 server.py
