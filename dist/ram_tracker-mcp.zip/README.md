# ram_tracker — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Monitor open PRs on GitHub repository and send instant alerts to Telegram bot

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
