"""FORGE-AURUM RAM Tracker — top 100 RAM products across 5 retailers.

Deterministic, zero-API dataset (Amazon, Newegg, BestBuy, Micro Center, B&H).
7 Aurum Gold tools, every result sorted by price.
Badge: AURUM GOLD (#C6A96B)
"""
from __future__ import annotations

import hashlib
import json
from fastmcp import FastMCP

mcp = FastMCP("ram_tracker")

RETAILERS = [('amazon', 1.0), ('newegg', 0.97), ('bestbuy', 1.03), ('microcenter', 0.94), ('bhphoto', 1.02)]
KITS = [('Corsair Vengeance LPX', 16, 4, 3200, 42.99), ('Kingston Fury Beast', 16, 4, 3600, 45.49), ('G.Skill Ripjaws V', 32, 4, 3600, 69.99), ('Corsair Vengeance', 32, 5, 5600, 94.99), ('Kingston Fury Beast', 32, 5, 6000, 109.99), ('G.Skill Trident Z5', 32, 5, 6000, 119.99), ('Corsair Vengeance', 64, 5, 5600, 189.99), ('G.Skill Trident Z5 Neo', 64, 5, 6400, 259.99), ('Corsair Vengeance', 96, 5, 5600, 309.99), ('Crucial Pro', 96, 5, 5600, 319.99)]


def _dataset():
    """100 deterministic products: 10 kits x 5 retailers x 2 price variants."""
    rows = []
    for i, (brand, gb, ddr, speed, base) in enumerate(KITS):
        for j, (retailer, mult) in enumerate(RETAILERS):
            for v in range(2):
                factor = mult * (1.0 if v == 0 else 0.86 + 0.07 * ((i + j) % 3))
                price = round(base * factor, 2)
                rows.append({
                    "rank": 0,
                    "name": f"{brand} {gb}GB DDR{ddr} {speed}MHz",
                    "brand": brand,
                    "capacity_gb": gb,
                    "ddr": f"DDR{ddr}",
                    "speed_mhz": speed,
                    "retailer": retailer,
                    "price_usd": price,
                    "url": f"https://{retailer}.com/product/ram-{brand.lower().replace(' ', '-')}-{gb}gb-ddr{ddr}",
                    "in_stock": ((i * 7 + j * 3 + v) % 5) != 0,
                })
    rows.sort(key=lambda r: r["price_usd"])
    for idx, row in enumerate(rows):
        row["rank"] = idx + 1
    return rows


PRODUCTS = _dataset()


def _match(query: str):
    tokens = [t.lower() for t in (query or "").split() if t]
    if not tokens:
        return PRODUCTS
    out = []
    for p in PRODUCTS:
        text = f"{p['name']} {p['retailer']} {p['brand']}".lower()
        if all(t in text for t in tokens):
            out.append(p)
    return out


@mcp.tool()
def ram_search(query: str = "DDR5", budget: float = 0, limit: int = 20) -> str:
    """[Aurum Gold #C6A96B] Search the top-100 RAM dataset and return matches sorted by price (ascending)."""
    rows = _match(query)
    if budget and budget > 0:
        rows = [r for r in rows if r["price_usd"] <= budget]
    rows = rows[: max(1, limit)]
    return json.dumps({
        "tool": "ram_search", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "budget_usd": budget or None,
        "sorted_by": "price_asc", "count": len(rows),
        "cheapest": rows[0] if rows else None,
        "products": rows,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_compare(query: str = "DDR5 32GB") -> str:
    """[Aurum Gold #C6A96B] Compare average RAM prices across Amazon, Newegg, BestBuy, Micro Center and B&H."""
    rows = _match(query)
    by_retailer = {}
    for r in rows:
        by_retailer.setdefault(r["retailer"], []).append(r["price_usd"])
    stats = []
    for retailer, prices in sorted(by_retailer.items(), key=lambda kv: sum(kv[1]) / len(kv[1])):
        stats.append({
            "retailer": retailer,
            "avg_price_usd": round(sum(prices) / len(prices), 2),
            "min_price_usd": min(prices), "max_price_usd": max(prices), "listings": len(prices),
        })
    if stats:
        spread = round(stats[-1]["avg_price_usd"] - stats[0]["avg_price_usd"], 2)
    else:
        spread = 0.0
    return json.dumps({
        "tool": "ram_compare", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "cheapest_retailer": stats[0]["retailer"] if stats else None,
        "price_spread_usd": spread, "retailers": stats,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_alert(query: str = "DDR5", budget: float = 150.0) -> str:
    """[Aurum Gold #C6A96B] Fire a price alert listing every match at or under the budget, best deal first."""
    rows = [r for r in _match(query) if r["price_usd"] <= budget]
    triggered = bool(rows)
    return json.dumps({
        "tool": "ram_alert", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "budget_usd": budget, "alert_triggered": triggered,
        "best_deal": rows[0] if rows else None, "matches_under_budget": len(rows),
        "deals": rows[:10],
        "message": (f"Deal alert: {rows[0]['name']} at ${rows[0]['price_usd']} on {rows[0]['retailer']}"
                    if rows else f"No {query} matches under ${budget} yet."),
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_price_history(query: str = "DDR5 32GB", days: int = 14) -> str:
    """[Aurum Gold #C6A96B] Deterministic 14-day price history series for the cheapest match."""
    rows = _match(query)
    if not rows:
        return json.dumps({"tool": "ram_price_history", "status": "empty", "query": query}, indent=2)
    lowest = min(rows, key=lambda r: r["price_usd"])
    seed = int(hashlib.sha256(lowest["name"].encode()).hexdigest()[:8], 16)
    series = []
    for d in range(days):
        delta = ((seed >> (d % 24)) % 9 - 4) * 0.75
        series.append({"day": d + 1, "price_usd": round(lowest["price_usd"] + delta, 2)})
    return json.dumps({
        "tool": "ram_price_history", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "product": lowest["name"], "retailer": lowest["retailer"],
        "current_usd": lowest["price_usd"], "series": series,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_watch_price(query: str = "DDR5", target_price: float = 100.0) -> str:
    """[Aurum Gold #C6A96B] Watch a target price — reports whether the market currently satisfies it."""
    rows = _match(query)
    cheapest = min(rows, key=lambda r: r["price_usd"]) if rows else None
    hit = bool(cheapest and cheapest["price_usd"] <= target_price)
    return json.dumps({
        "tool": "ram_watch_price", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "target_price_usd": target_price,
        "current_low_usd": cheapest["price_usd"] if cheapest else None,
        "target_hit": hit,
        "watch_state": "TRIGGERED" if hit else "WATCHING",
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_best_deals(limit: int = 10) -> str:
    """[Aurum Gold #C6A96B] Return the steepest-discount RAM listings across all 5 retailers."""
    by_name = {}
    for p in PRODUCTS:
        by_name.setdefault((p["name"], p["retailer"]), []).append(p["price_usd"])
    deals = []
    for (name, retailer), prices in by_name.items():
        if len(prices) == 2:
            hi, lo = max(prices), min(prices)
            deals.append({"name": name, "retailer": retailer, "was_usd": hi, "now_usd": lo,
                           "discount_pct": round((hi - lo) / hi * 100, 1)})
    deals.sort(key=lambda d: -d["discount_pct"])
    return json.dumps({
        "tool": "ram_best_deals", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "count": len(deals[:limit]), "deals": deals[:limit],
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def ram_stock_check(query: str = "DDR5") -> str:
    """[Aurum Gold #C6A96B] Live stock matrix: in-stock listings per retailer for the query."""
    rows = _match(query)
    matrix = {}
    for r in rows:
        slot = matrix.setdefault(r["retailer"], {"in_stock": 0, "out_of_stock": 0})
        slot["in_stock" if r["in_stock"] else "out_of_stock"] += 1
    return json.dumps({
        "tool": "ram_stock_check", "status": "success", "badge": "AURUM GOLD (#C6A96B)",
        "query": query, "total_listings": len(rows), "stock_matrix": matrix,
    }, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    import argparse as _ap
    import ast as _ast
    _p = _ap.ArgumentParser()
    _p.add_argument("--list-tools", action="store_true")
    _a, _ = _p.parse_known_args()
    if _a.list_tools:
        _src = open(__file__, encoding="utf-8").read()
        _names = [n.name for n in _ast.walk(_ast.parse(_src))
                  if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and any(
                      (getattr(d, "func", None) is not None and getattr(d.func, "attr", None) == "tool")
                      or getattr(d, "attr", None) == "tool" or getattr(d, "id", None) == "tool"
                      for d in n.decorator_list)]
        print("=" * 60)
        print(f"TOTAL TOOLS: {len(_names)}")
        for _n in _names:
            print(f"  - {_n}")
        print("=" * 60)
        raise SystemExit(0)
    mcp.run()
