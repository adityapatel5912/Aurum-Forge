#!/usr/bin/env bash
echo "Hot-loading gmail_mcp..."
python3 server.py
