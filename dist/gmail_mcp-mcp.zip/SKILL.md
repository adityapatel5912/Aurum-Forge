---
name: gmail_mcp
description: Build Gmail MCP that sends and reads emails with 3 tools gmail_send gmail_read gmail_search
version: 1.0.0
mcp_server: gmail_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build Gmail MCP that sends and reads emails with 3 tools gmail_send gmail_read gmail_search

## 1. Overview & Golden Badge
- **MCP Server Name**: `gmail_mcp`
- **Server Path**: `mcp/gmail_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build Gmail MCP that sends and reads emails with 3 tools gmail_send gmail_read gmail_search

## 2. FastMCP Tool Manifest
- `gmail_send` [FORGED]: Send emails via Gmail
- `gmail_read` [FORGED]: Read email details and bodies
- `gmail_search` [FORGED]: Search email threads

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "gmail_send",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "gmail_read",
    "source": "Intent Router",
    "parallel": true
  },
  "t3": {
    "tool": "gmail_search",
    "source": "Intent Router",
    "parallel": true
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build Gmail MCP that sends and reads emails with 3 tools gmail_send gmail_read gmail_search"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `gmail_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `gmail_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `gmail_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add gmail_mcp -- python "mcp/gmail_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
