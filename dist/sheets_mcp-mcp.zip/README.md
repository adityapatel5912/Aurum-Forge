# sheets_mcp — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Build Google Sheets MCP that reads and writes sheets with 4 tools sheets_read sheets_write sheets_append sheets_create

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
