---
name: sheets_mcp
description: Build Google Sheets MCP that reads and writes sheets with 4 tools sheets_read sheets_write sheets_append sheets_create
version: 1.0.0
mcp_server: sheets_mcp
aurum_badge: "AURUM GOLD (#C6A96B)"
compatible_ides:
  - Antigravity
  - Z Code
  - Claude Code
  - Cursor
  - Windsurf
  - OpenCode
  - Codex
---

# Universal Skill: Build Google Sheets MCP that reads and writes sheets with 4 tools sheets_read sheets_write sheets_append sheets_create

## 1. Overview & Golden Badge
- **MCP Server Name**: `sheets_mcp`
- **Server Path**: `mcp/sheets_mcp/server.py`
- **Aurum Verification**: Gold Verified `#C6A96B` (Self-Heal Active, Deterministic <2.1s, 0 Token Cost)
- **Target Goal**: Build Google Sheets MCP that reads and writes sheets with 4 tools sheets_read sheets_write sheets_append sheets_create

## 2. FastMCP Tool Manifest
- `sheets_read` [FORGED]: Read rows and columns from sheet
- `sheets_write` [FORGED]: Write matrix of values to sheet
- `sheets_append` [FORGED]: Append row to sheet
- `sheets_create` [FORGED]: Create new Google spreadsheet

## 3. Levelled Workflow DAG
```json
{
  "t1": {
    "tool": "sheets_read",
    "source": "Intent Router",
    "parallel": true
  },
  "t2": {
    "tool": "sheets_write",
    "source": "Intent Router",
    "parallel": true
  },
  "t3": {
    "tool": "sheets_append",
    "source": "Intent Router",
    "parallel": true
  },
  "t4": {
    "tool": "sheets_create",
    "source": "Intent Router",
    "deps": [
      "t1",
      "t2",
      "t3"
    ]
  }
}
```

## 4. Execution Protocol for AI Agents
When the user requests **"Build Google Sheets MCP that reads and writes sheets with 4 tools sheets_read sheets_write sheets_append sheets_create"** or asks to execute this workflow:
1. **Direct Invocation**: Use the tools exposed by `sheets_mcp` directly. Do not guess parameters or synthesize ad-hoc browser scripts.
2. **Topological Order**: Follow the DAG stages. Feed output payloads from Trigger -> Process -> Output nodes.
3. **Resilience**: If a locator encounters a dynamic DOM change, the built-in 2-locator fallback self-heals in `<200ms`.

## 5. Universal IDE Configuration
Connect this skill to your favorite IDE with 1-click via `forge.mcp.json`:
- **Antigravity**: Add `sheets_mcp` to `~/.antigravity/mcp.json`
- **Z Code**: Add `sheets_mcp` to `settings.json` under `mcpServers`
- **Claude Code**: Run `claude mcp add sheets_mcp -- python "mcp/sheets_mcp/server.py"`
- **Cursor / Windsurf**: Add to `.cursor/mcp.json` or `.codeium/windsurf/mcp_config.json`
