"""FORGE-AURUM Google Sheets MCP — 4 tools covering reading, writing, appending, and creating.

Badge: AURUM GOLD (#C6A96B)
"""
from __future__ import annotations

import hashlib
import json
import time
from fastmcp import FastMCP

mcp = FastMCP("sheets_mcp")

SHEETS_DB: dict = {
    "sheet-001": [
        ["Product", "Retailer", "Price", "Stock"],
        ["Corsair Vengeance 32GB", "Amazon", "$94.99", "In Stock"],
        ["Kingston Fury 32GB", "Newegg", "$109.99", "In Stock"],
        ["G.Skill Trident 64GB", "Micro Center", "$259.99", "In Stock"],
    ]
}


@mcp.tool()
def sheets_read(spreadsheet_id: str = "sheet-001", range_name: str = "Sheet1!A1:D10") -> str:
    """[Aurum Gold #C6A96B] Reads rows and cell values from a spreadsheet range."""
    data = SHEETS_DB.get(spreadsheet_id, SHEETS_DB["sheet-001"])
    return json.dumps({
        "tool": "sheets_read",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "spreadsheet_id": spreadsheet_id,
        "range": range_name,
        "rows_count": len(data),
        "values": data,
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def sheets_write(spreadsheet_id: str = "sheet-001", range_name: str = "Sheet1!A1", values_json: str = "[[]]") -> str:
    """[Aurum Gold #C6A96B] Writes a matrix of values into a spreadsheet range."""
    try:
        vals = json.loads(values_json) if values_json else []
    except Exception:
        vals = [[values_json]]
    if spreadsheet_id not in SHEETS_DB:
        SHEETS_DB[spreadsheet_id] = []
    SHEETS_DB[spreadsheet_id].extend(vals)
    return json.dumps({
        "tool": "sheets_write",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "spreadsheet_id": spreadsheet_id,
        "range": range_name,
        "updated_rows": len(vals),
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def sheets_append(spreadsheet_id: str = "sheet-001", range_name: str = "Sheet1!A1", row_json: str = "[]") -> str:
    """[Aurum Gold #C6A96B] Appends a single row of values to the bottom of the sheet."""
    try:
        row = json.loads(row_json) if row_json else ["New Entry", "Auto", "$0.00", "Logged"]
    except Exception:
        row = [row_json]
    SHEETS_DB.setdefault(spreadsheet_id, []).append(row)
    return json.dumps({
        "tool": "sheets_append",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "spreadsheet_id": spreadsheet_id,
        "appended_row": row,
        "total_rows": len(SHEETS_DB[spreadsheet_id]),
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def sheets_create(title: str = "Aurum Telemetry Data", columns_json: str = "[]") -> str:
    """[Aurum Gold #C6A96B] Creates a new Google Spreadsheet and returns spreadsheet_id and url."""
    sheet_id = "sheet_" + hashlib.sha256(f"{title}-{time.time()}".encode()).hexdigest()[:10]
    try:
        cols = json.loads(columns_json) if columns_json else ["ID", "Name", "Value", "Timestamp"]
    except Exception:
        cols = ["Col1", "Col2", "Col3"]
    SHEETS_DB[sheet_id] = [cols]
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/edit"
    return json.dumps({
        "tool": "sheets_create",
        "status": "success",
        "badge": "AURUM GOLD (#C6A96B)",
        "spreadsheet_id": sheet_id,
        "title": title,
        "url": url,
        "columns": cols,
    }, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    import argparse as _ap
    import ast as _ast
    _p = _ap.ArgumentParser()
    _p.add_argument("--list-tools", action="store_true")
    _a, _ = _p.parse_known_args()
    if _a.list_tools:
        _src = open(__file__, encoding="utf-8").read()
        _names = [n.name for n in _ast.walk(_ast.parse(_src))
                  if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and any(
                      (getattr(d, "func", None) is not None and getattr(d.func, "attr", None) == "tool")
                      or getattr(d, "attr", None) == "tool" or getattr(d, "id", None) == "tool"
                      for d in n.decorator_list)]
        print("=" * 60)
        print(f"TOTAL TOOLS: {len(_names)}")
        for _n in _names:
            print(f"  - {_n}")
        print("=" * 60)
        raise SystemExit(0)
    mcp.run()
