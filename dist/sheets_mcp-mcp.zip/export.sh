#!/usr/bin/env bash
echo "Hot-loading sheets_mcp..."
python3 server.py
