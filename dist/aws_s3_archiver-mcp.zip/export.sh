#!/usr/bin/env bash
# FORGE 1-Click Multi-Agent MCP Exporter (Linux / macOS)
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
if [ -f "$DIR/server.py" ]; then
    RUN_PATH="$DIR/server.py"
else
    RUN_PATH="D:/Aditya/Forge/mcp/aws_s3_archiver/server.py"
fi

echo "========================================================"
echo "Exporting MCP Server 'aws_s3_archiver' to AI Agents..."
echo "Server Path: $RUN_PATH"
echo "========================================================"

if command -v claude &> /dev/null; then
    echo "[1/3] Adding to Claude Code..."
    claude mcp add aws_s3_archiver -- python "$RUN_PATH" || true
else
    echo "[SKIP] Claude Code CLI not found."
fi

if command -v codex &> /dev/null; then
    echo "[2/3] Adding to Codex..."
    codex mcp add aws_s3_archiver -- python "$RUN_PATH" || true
else
    echo "[SKIP] Codex CLI not found."
fi

if command -v opencode &> /dev/null; then
    echo "[3/3] Adding to OpenCode..."
    opencode mcp add aws_s3_archiver -- python "$RUN_PATH" || true
else
    echo "[SKIP] OpenCode CLI not found."
fi

echo ""
echo "For Cursor, Zed, and Antigravity, see export_configs.json for JSON configuration."
echo "Done!"
