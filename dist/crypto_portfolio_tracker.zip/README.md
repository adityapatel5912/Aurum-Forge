# FORGE UNIFIED MCP — CONFIG ONCE

One server (crypto_portfolio_tracker) operates 0 custom site(s) + 0 official MCP(s).
0 core + 0 forged + 0 official = 0 tools total.

## Setup — one time only

1. Unzip this archive anywhere you like.
2. Install dependencies:
   ```
   pip install -r requirements.txt && playwright install chromium
   ```
3. Export to your AI Agent:
   - Run `export.bat` (Windows) or `bash export.sh` (macOS / Linux) to configure Claude Code, Codex, and OpenCode automatically.
   - For Cursor, Zed, and Antigravity: consult `export_configs.json` for ready-to-use JSON blocks.
4. Workflow Skill:
   `SKILL.md` is provided at the root as the single source of truth for your agent.

## Official MCP tokens

- `NOTION_TOKEN` / `NOTION_DATABASE_ID` — Notion core (log_price, create entry)
- `GMAIL_USER` / `GMAIL_APP_PASSWORD` / `GMAIL_TO` — Gmail core (SMTP app password)

## Test without any client

```
npx @modelcontextprotocol/inspector python server.py
```
or simply:
```
python server.py --list-tools
```

## Hardcoded core tools (always included, no LLM was used)

- none

## Forged tools (browser automation, two-locator self-healing)

- none

## Official wrappers

- none

---
Forged by FORGE v2.0.0 — Turn Any Website Into A Reusable MCP Server.
