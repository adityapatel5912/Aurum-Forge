#!/usr/bin/env bash
echo "Hot-loading chain_sales_outreach..."
python3 server.py
