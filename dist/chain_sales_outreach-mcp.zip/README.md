# chain_sales_outreach — Universal Aurum FastMCP Server

**Aurum Gold Badge `#C6A96B` Verified**
Goal: Automated B2B growth engine: scrapes high-intent leads from targeted directories, tracks prospect pipeline in Google Sheets, dispatches personalized cold emails via Gmail, and writes lead cards to Notion CRM. Rewrites 4 hours of sales labor.

## Quick Start
1. `pip install -r requirements.txt`
2. `python server.py`
3. Connect with any IDE using `forge.mcp.json` or standard MCP client.
