# FORGE UNIFIED MCP — CONFIG ONCE

One server (unified-forge) operates 2 custom site(s) + 0 official MCP(s).
0 core + 2 forged + 0 official = 2 tools total.

## Setup — one time only

1. Unzip this archive anywhere you like.
2. Install dependencies:
   ```
   pip install -r requirements.txt && playwright install chromium
   ```
3. Export to your AI Agent of choice using `export_configs.json` or CLI commands:
   - Claude Code: `claude mcp add unified-forge -- python D:/Aditya/Forge/mcp_registry/servers/unified-mcp/server.py`
   - Cursor: copy config into `.cursor/mcp.json`
   - Z Code (Zed): add to `settings.json` under `context_servers`
   - OpenCode: add to `opencode_mcp.json`
   - Antigravity: `agy mcp add unified-forge -- python D:/Aditya/Forge/mcp_registry/servers/unified-mcp/server.py`
   - Codex: `codex mcp add unified-forge -- python D:/Aditya/Forge/mcp_registry/servers/unified-mcp/server.py`
4. Workflow Skill:
   `SKILL.md` is provided at the root as the single source of truth for your agent.

## Official MCP tokens

- `NOTION_TOKEN` / `NOTION_DATABASE_ID` — Notion core (log_price, create entry)
- `GMAIL_USER` / `GMAIL_APP_PASSWORD` / `GMAIL_TO` — Gmail core (SMTP app password)

## Test without any client

```
npx @modelcontextprotocol/inspector python server.py
```
or simply:
```
python server.py --list-tools
```

## Hardcoded core tools (always included, no LLM was used)

- none

## Forged tools (browser automation, two-locator self-healing)

- `devpost_search_hackathons` — Custom devpost.com Forged
- `mlh_get_events` — Custom mlh.io Forged

## Official wrappers

- none

---
Forged by FORGE v1.0.0 — Turn Any Website Into A Reusable MCP Server.
